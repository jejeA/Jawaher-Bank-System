package com.example.demo.Jwa.Bank.System.Controller;

import com.example.demo.Jwa.Bank.System.Entity.Account;
import com.example.demo.Jwa.Bank.System.Entity.AccountHolder;
import com.example.demo.Jwa.Bank.System.Entity.AccountStatus;
import com.example.demo.Jwa.Bank.System.Repository.AccountHolderRepository;
import com.example.demo.Jwa.Bank.System.Repository.AccountRepository;
import com.example.demo.Jwa.Bank.System.Services.Implementation.AccountHolderServiceImp;
import com.example.demo.Jwa.Bank.System.Services.Implementation.AccountServiceImp;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.Arrays;
import java.util.List;

import static com.example.demo.Jwa.Bank.System.Entity.AccountStatus.SavingAccount;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
class AccountHolderControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;
    private MockMvc mockMvc;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @MockBean
    private AccountHolderServiceImp accountHolderServiceImp;

    @MockBean
    private Account account;


    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void testDeleteAccountHolder() throws Exception {
        int idToDelete = 8745; // Replace with the desired ID to delete

        // Mock the service to handle the account holder deletion
        when(accountHolderServiceImp.deleteAccountHolder(idToDelete)).thenReturn("Account holder deleted successfully");

        mockMvc.perform(MockMvcRequestBuilders.delete("/delete/{id}", idToDelete)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.content().string("Account holder deleted successfully"))
                .andReturn();
    }


}