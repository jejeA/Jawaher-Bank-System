package com.example.demo.Jwa.Bank.System.Entity;

//public enum  AccountStatus {
//    SavingAccount ,
//    CheckingAccount
//}
public enum AccountStatus {
    // Enumeration representing different account statuses.

    SavingAccount, // Represents a Saving Account
    CheckingAccount // Represents a Checking Account
}
