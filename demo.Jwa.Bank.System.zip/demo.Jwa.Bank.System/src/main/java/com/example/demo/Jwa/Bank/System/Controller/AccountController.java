package com.example.demo.Jwa.Bank.System.Controller;

import com.example.demo.Jwa.Bank.System.Entity.Account;
import com.example.demo.Jwa.Bank.System.Entity.AccountHolder;
import com.example.demo.Jwa.Bank.System.Services.Implementation.AccountServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@RestController
//public class  AccountController {
//
//    @Autowired
//    private AccountServiceImp accountServiceImp;
//
//
//    @GetMapping("/accounts")
//    public List<Account> getAllAccount() {
//        return accountServiceImp.getAllAccount();
//    }
//
//
//
//    @PostMapping("/add/account")
//    public ResponseEntity<String> addAccoun(@RequestBody Account account) {
//        try {
//
//            accountServiceImp.addAccount(account);
//            String message = "Account added successfully";
//            return ResponseEntity.status(HttpStatus.CREATED).body(message);
//        }
//        catch (Exception e) {
//            String errormessage="Account not added successfully";
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errormessage);
//
//        }
//    }
//
//
//    @PostMapping("/deposit/{accountNumber}")
//    public ResponseEntity<String> deposit(@PathVariable int accountNumber, @RequestParam double amount) {
//        try {
//            String message = accountServiceImp.deposit(accountNumber, amount);
//            return ResponseEntity.status(HttpStatus.OK).body(message);
//
//        } catch (Exception e) {
//            String errormessage = "deposit not added seccessfully";
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errormessage);
//        }
//    }
//
//    @PostMapping("/withdraw/{accountNumber}")
//    public ResponseEntity<String> withdraw(@PathVariable int accountNumber, @RequestParam double amount) {
//        try {
//            String response = accountServiceImp.withdraw(accountNumber, amount);
//            return ResponseEntity.status(HttpStatus.OK).body(response);
//
//        } catch (Exception e) {
//            String errormessage = "deposit not added seccessfully";
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errormessage);
//        }
//
//    }
//
////    @PostMapping("/transfer")
////    public ResponseEntity<String> transfer(
////            @RequestParam int sourceAccountNumber,
////            @RequestParam int targetAccountNumber,
////            @RequestParam double amount
////    ) {
////        String response = accountServiceImp.transfer(sourceAccountNumber, targetAccountNumber, amount);
////        HttpStatus status = response.contains("successful") ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
////        return new ResponseEntity<>(response, status);
////    }
//@PostMapping("/transfer")
//public ResponseEntity<String> transfer(
//        @RequestParam("sourceAccountNumber") int sourceAccountNumber,
//        @RequestParam("targetAccountNumber") int targetAccountNumber,
//        @RequestParam("amount") double amount) {
//
//    String message = accountServiceImp.transfer(sourceAccountNumber, targetAccountNumber, amount);
//
//    if ("Successful transfer".equals(message)) {
//        return ResponseEntity.status(HttpStatus.OK).body(message);
//    } else {
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
//    }
//}
//
//        @GetMapping("/balance/{accountNumber}")
//    public ResponseEntity<String> showBalance(@PathVariable int accountNumber) {
//        try {
//           String response = accountServiceImp.showBalance(accountNumber);
//                return ResponseEntity.status(HttpStatus.OK).body(response);
//        } catch (Exception e) {
//            String errorMessage = "Failed to retrieve balance for account number: " + accountNumber;
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage);
//        }
//    }
//
//
//}
//
//



@RestController
public class AccountController {

    @Autowired
    private AccountServiceImp accountServiceImp;

    // GET Method: Get all accounts
    @GetMapping("/accounts")
    public List<Account> getAllAccount() {
        return accountServiceImp.getAllAccount();
    }

    // POST Method: Add an account
    @PostMapping("/add/account")
    public ResponseEntity<String> addAccoun(@RequestBody Account account) {
        try {
            // Attempt to create an account
            accountServiceImp.addAccount(account);
            String message = "Account added successfully";
            return ResponseEntity.status(HttpStatus.CREATED).body(message); // Return success response
        } catch (DataIntegrityViolationException
                e) {
            String errorMessage = "Account not added successfully: " + e.getRootCause().getMessage();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage); // Return error response
        }
    }

    // POST Method: Deposit into an account
    @PostMapping("/deposit/{accountNumber}")
    public ResponseEntity<String> deposit(@PathVariable int accountNumber, @RequestParam double amount) {
        try {
            // Attempt to deposit into an account
            String message = accountServiceImp.deposit(accountNumber, amount);
            return ResponseEntity.status(HttpStatus.OK).body(message); // Return success response
        } catch (Exception e) {
            String errorMessage = "Deposit not added successfully: " + e.getMessage();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage); // Return error response
        }
    }

    // POST Method: Withdraw from an account
    @PostMapping("/withdraw/{accountNumber}")
    public ResponseEntity<String> withdraw(@PathVariable int accountNumber, @RequestParam double amount) {
        try {
            // Attempt to withdraw from an account
            String response = accountServiceImp.withdraw(accountNumber, amount);
            return ResponseEntity.status(HttpStatus.OK).body(response); // Return success response
        } catch (Exception e) {
            String errorMessage = "Withdrawal not added successfully: " + e.getMessage();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage); // Return error response
        }
    }

    // POST Method: Transfer between accounts
    @PostMapping("/transfer")
    public ResponseEntity<String> transfer(
            @RequestParam("sourceAccountNumber") int sourceAccountNumber,
            @RequestParam("targetAccountNumber") int targetAccountNumber,
            @RequestParam("amount") double amount) {
        // Attempt to transfer between accounts
        String message = accountServiceImp.transfer(sourceAccountNumber, targetAccountNumber, amount);
        if ("Successful transfer".equals(message)) {
            return ResponseEntity.status(HttpStatus.OK).body(message); // Return success response
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message); // Return error response
        }
    }

    // GET Method: Get the balance of an account
    @GetMapping("/balance/{accountNumber}")
    public ResponseEntity<String> showBalance(@PathVariable int accountNumber) {
        try {
            // Attempt to retrieve the balance of an account
            String response = accountServiceImp.showBalance(accountNumber);
            return ResponseEntity.status(HttpStatus.OK).body(response); // Return success response
        } catch (Exception e) {
            String errorMessage = "Failed to retrieve balance for account number: " + accountNumber;
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage); // Return error response
        }
    }
}
