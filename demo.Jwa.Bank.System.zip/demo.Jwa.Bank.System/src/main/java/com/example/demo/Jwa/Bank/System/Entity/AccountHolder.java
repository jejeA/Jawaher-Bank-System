package com.example.demo.Jwa.Bank.System.Entity;


import jakarta.persistence.*;
import lombok.*;
import java.util.*;


//@Entity
//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//@Data
//
//@Table(name = "tbl_AccountHolder")
//public class AccountHolder extends User{
//
//
//    @OneToOne
//    private Account account;
//
//    public AccountHolder(int idUser, String name, String email, String password, String address,Account account) {
//        super(idUser, name, email, password, address);
//        setAccount(account);
//    }
//
//}
//
//
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Data
@Table(name = "tbl_AccountHolder")
public class AccountHolder extends User {

    // Class representing an Account Holder entity.

    @OneToOne
    private Account account; // One-to-one relationship with Account entity

    public AccountHolder(int idUser, String name, String email, String password, String address, Account account) {
        super(idUser, name, email, password, address);
        setAccount(account);
    }


}
