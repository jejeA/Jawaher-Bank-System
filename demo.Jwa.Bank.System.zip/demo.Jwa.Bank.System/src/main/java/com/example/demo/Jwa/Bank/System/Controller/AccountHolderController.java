package com.example.demo.Jwa.Bank.System.Controller;

import com.example.demo.Jwa.Bank.System.Entity.AccountHolder;
import com.example.demo.Jwa.Bank.System.Entity.AccountHolderNotFoundException;
import com.example.demo.Jwa.Bank.System.Services.Implementation.AccountHolderServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

//@RestController
//public class AccountHolderController {
//
//    @Autowired
//    private AccountHolderServiceImp accountHolderServiceImp;
//
//
//    @GetMapping("/alltables")
//    public List<AccountHolder> getAllAccountHolders() {
//        return accountHolderServiceImp.getAllAccountHolders();
//    }
//
//    @GetMapping("/Accountholder/{id}")
//    public Optional<AccountHolder> findByAccountHoldertId(@PathVariable int id) {
//        return accountHolderServiceImp.findByAccountHoldertId(id);
//    }
//
//    @PostMapping("/add/accountholder")
//    public ResponseEntity<String> addAccountHolder(@RequestBody  AccountHolder accountHolder) {
//        try {
//            // AccountHolder createdAccountHolder = accountHolderServiceImp.createAccountHolder(accountHolder);
//            accountHolderServiceImp.createAccountHolder(accountHolder);
//            String message = "AcountHolder added seccessfully";
//            return ResponseEntity.status(HttpStatus.CREATED).body(message);
//        }
//     catch (Exception e) {
//                String errormessage="AcountHolder not added seccessfully" + e.getMessage();
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errormessage);
//
//            }
//        }
//
//
//    @PutMapping("/update/{id}")
//    public ResponseEntity<String> updateAccountHolder(@PathVariable int id, @RequestBody AccountHolder accountHolder) {
//        String updatedAccountHolder = accountHolderServiceImp.updateAccountHolder(id, accountHolder);
//
//        if (updatedAccountHolder != null) {
//            String message = "Account holder updated successfully";
//            return ResponseEntity.ok(message);
//        } else {
//            throw new AccountHolderNotFoundException("Account holder with the given ID not found");
//        }
//    }
//
//
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<String> deleteAccountHolder(@PathVariable int id) {
//       try{
//       String message= accountHolderServiceImp.deleteAccountHolder(id);
//        return ResponseEntity.status(HttpStatus.OK).body(message);
//
//    } catch (Exception e) {
//        String errormessage = "account not deleted seccessfully";
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errormessage);
//    }
//    }
//}
//

@RestController
public class AccountHolderController {

    @Autowired
    private AccountHolderServiceImp accountHolderServiceImp;

    // GET Method: Get all account holders
    @GetMapping("/alltables")
    public List<AccountHolder> getAllAccountHolders() {
        return accountHolderServiceImp.getAllAccountHolders();
    }

    // GET Method: Find an account holder by ID
    @GetMapping("/Accountholder/{id}")
    public ResponseEntity<?> findByAccountHoldertId(@PathVariable int id) {
        // Attempt to find the account holder
        Optional<AccountHolder> accountHolder = accountHolderServiceImp.findByAccountHoldertId(id);
        if (accountHolder.isPresent()) {
            return ResponseEntity.ok(accountHolder.get()); // Account holder found, return it
        } else {
            return ResponseEntity.notFound().build(); // Account holder not found, return 404 Not Found
        }
    }

    // POST Method: Add an account holder
    @PostMapping("/add/accountholder")
    public ResponseEntity<String> addAccountHolder(@RequestBody AccountHolder accountHolder) {
        try {
            // Attempt to create an account holder
            accountHolderServiceImp.createAccountHolder(accountHolder);
            String message = "Account holder added successfully";
            return ResponseEntity.status(HttpStatus.CREATED).body(message); // Return success response
        } catch (DataIntegrityViolationException e) {
            String errorMessage = "Account holder not added successfully: " + e.getRootCause().getMessage();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage); // Return error response
        }
    }

    // PUT Method: Update an account holder
    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateAccountHolder(@PathVariable int id, @RequestBody AccountHolder accountHolder) {
        try {
            // Attempt to update the account holder
            String updatedAccountHolder = accountHolderServiceImp.updateAccountHolder(id, accountHolder);
            if (updatedAccountHolder != null) {
                String message = "Account holder updated successfully";
                return ResponseEntity.ok(message); // Return success response
            } else {
                return ResponseEntity.notFound().build(); // Account holder not found, return 404 Not Found
            }
        } catch (Exception e) {
            String errorMessage = "Account holder update failed: " + e.getMessage();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMessage); // Return error response
        }
    }

    // DELETE Method: Delete an account holder
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAccountHolder(@PathVariable int id) {
        try {
            // Attempt to delete the account holder
            String message = accountHolderServiceImp.deleteAccountHolder(id);
            return ResponseEntity.ok(message); // Return success response
        } catch (EmptyResultDataAccessException e) {
            return ResponseEntity.notFound().build(); // Account holder not found, return 404 Not Found
        } catch (Exception e) {
            String errorMessage = "Account not deleted successfully: " + e.getMessage();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage); // Return error response
        }
    }
}
