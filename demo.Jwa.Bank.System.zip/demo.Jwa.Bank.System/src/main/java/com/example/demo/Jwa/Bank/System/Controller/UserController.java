package com.example.demo.Jwa.Bank.System.Controller;

import org.springframework.web.bind.annotation.*;



@RestController
public class UserController {



}