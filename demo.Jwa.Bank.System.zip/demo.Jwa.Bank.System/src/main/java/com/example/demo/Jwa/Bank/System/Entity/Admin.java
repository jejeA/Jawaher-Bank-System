package com.example.demo.Jwa.Bank.System.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_Admin")
public class Admin extends User{


}
