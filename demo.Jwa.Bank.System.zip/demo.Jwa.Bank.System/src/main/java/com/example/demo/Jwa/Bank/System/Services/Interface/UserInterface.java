package com.example.demo.Jwa.Bank.System.Services.Interface;

import com.example.demo.Jwa.Bank.System.Entity.User;

import java.util.List;

public interface UserInterface {


}
